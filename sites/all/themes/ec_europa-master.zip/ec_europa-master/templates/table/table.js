/**
 * @file
 * JS file for Europa theme.
 */

(function ($) {
  Drupal.behaviors.ecEuropaTable = {
    attach: function (context) {
      ECL.eclTables();
    }
  };
})(jQuery);
