<?php

/**
 * @file
 * Contains component file.
 */
?>
<div<?php print $atomium['attributes']['wrapper']; ?>>
  <div class="ecl-container">
    <?php print render($links); ?>
  </div>
</div>
