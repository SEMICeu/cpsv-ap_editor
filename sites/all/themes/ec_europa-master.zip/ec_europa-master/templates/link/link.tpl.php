<?php

/**
 * @file
 * Contains template file.
 */
?>
<a<?php print $atomium['attributes']['element']; ?>><?php print render($prefix); ?><?php print render($text); ?></a>
