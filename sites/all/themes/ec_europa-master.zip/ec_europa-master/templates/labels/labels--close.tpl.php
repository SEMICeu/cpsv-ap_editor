<?php

/**
 * @file
 * Contains template file.
 */
?>
<span<?php print $atomium['attributes']['wrapper']->append('class', 'ecl-label--close'); ?>>
  <?php print $content; ?>
</span>
