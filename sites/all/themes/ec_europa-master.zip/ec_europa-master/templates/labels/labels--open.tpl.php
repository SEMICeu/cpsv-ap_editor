<?php

/**
 * @file
 * Contains template file.
 */
?>
<span<?php print $atomium['attributes']['wrapper']->append('class', 'ecl-label--open'); ?>>
  <?php print $content; ?>
</span>
