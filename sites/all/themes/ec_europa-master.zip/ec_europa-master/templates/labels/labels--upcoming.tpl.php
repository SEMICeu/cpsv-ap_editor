<?php

/**
 * @file
 * Contains template file.
 */
?>
<span<?php print $atomium['attributes']['wrapper']->append('class', 'ecl-label--upcoming'); ?>>
  <?php print $content; ?>
</span>
