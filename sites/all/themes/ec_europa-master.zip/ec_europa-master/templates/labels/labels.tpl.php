<?php

/**
 * @file
 * Contains template file.
 */
?>
<span<?php print $atomium['attributes']['wrapper']; ?>><?php print $content; ?></span>
