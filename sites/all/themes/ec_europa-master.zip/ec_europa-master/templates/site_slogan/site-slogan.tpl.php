<?php

/**
 * @file
 * Contains template file.
 */
?>
<h2 class="site-slogan"><?php print render($site_slogan); ?></h2>
