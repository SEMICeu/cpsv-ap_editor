<?php

/**
 * @file
 * Contains template file.
 */
?>
<label class="ecl-search-form__textfield-wrapper">
  <?php print render($label); ?>
  <?php print $element['#children']; ?>
</label>
