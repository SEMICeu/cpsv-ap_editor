<?php

/**
 * @file
 * Contains template file.
 */
?>
<span class="ecl-u-sr-only"><?php print render($form_element_label['title']); ?></span>
