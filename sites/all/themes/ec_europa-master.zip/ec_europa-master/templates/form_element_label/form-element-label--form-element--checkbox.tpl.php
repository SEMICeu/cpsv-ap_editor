<?php

/**
 * @file
 * Contains template file.
 */
?>
<span<?php print $atomium['attributes']['wrapper']; ?>>
  <?php print render($form_element_label['title']); ?>
  <?php print render($form_element_label['required']); ?>
</span>
