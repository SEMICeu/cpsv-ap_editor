<?php

/**
 * @file
 * Contains component file.
 */
?>
<span<?php print $atomium['attributes']['wrapper']; ?>><?php print render($text); ?></span>
