<?php

/**
 * @file
 * Contains template file.
 */
?>
<?php print render($tags); ?>
