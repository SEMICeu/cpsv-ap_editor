<?php

/**
 * @file
 * Contains component file.
 */
?>

<?php print render($search_form); ?>
