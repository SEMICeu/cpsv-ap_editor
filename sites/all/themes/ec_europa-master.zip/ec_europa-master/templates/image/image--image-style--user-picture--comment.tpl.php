<?php

/**
 * @file
 * Contains template file.
 */
?>
<img<?php print $atomium['attributes']['element']->append('class', 'ecl-comment__image'); ?>/>
