This folder is where you should place all your overriding template files. By
default, the Atomium base theme provides all the necessary template files in
various folders inside of sites/*/themes/atomium/templates. For example, the
page.tpl.php template file is located at
sites/*/themes/atomium/templates/page/page.tpl.php. To override any of these
files, copy them from the Atomium base theme and place them in here.

For more information about the template management, please read the README file
of Atomium theme.
