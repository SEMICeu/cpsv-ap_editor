<?php

/**
 * @file
 * Contains template file.
 */
?>
<a<?php print $atomium['attributes']['a']; ?>>
    <span class="ecl-u-sr-only"><?php print $title; ?></span>
</a>
