<?php

/**
 * @file
 * Contains template file.
 */
?>
<?php print render($views_mini_pager); ?>
