SUMMARY
-------
SPARQL module provides an API for other modules to use to run SPARQL queries.
Queries can be run against external SPARQL endpoints or against RDF files,
either local or on the Web. Running queries against files requires MySQL.


BUG REPORTS
-----------
Post bug reports and feature requests to the issue tracking system at:

<http://drupal.org/project/issues/sparql>