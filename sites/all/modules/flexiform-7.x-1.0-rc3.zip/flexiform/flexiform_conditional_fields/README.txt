INSTALLATION
------------

This module requires Conditional Fields (3.x) and the following patch to operate:

https://www.drupal.org/node/2298953#comment-8946105