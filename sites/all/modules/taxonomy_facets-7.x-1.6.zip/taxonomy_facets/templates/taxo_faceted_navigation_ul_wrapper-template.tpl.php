<?php
/**
 * @file
 * Template for block wraper of the filters block
 *
 * Wrups up the block.
 */

?>
<ul class="menu clearfix">
<?php print $ul_sub_menu; ?>
</ul>
