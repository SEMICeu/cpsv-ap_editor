<?php
// $Id: votingapi.api.php,v 1.1.2.1.2.1 2009/07/01 07:26:12 eaton Exp $

/**
 * @file
 * Provides hook documentation for the RDFx module.
 */

function hook_rdfx_term_types_alter()
