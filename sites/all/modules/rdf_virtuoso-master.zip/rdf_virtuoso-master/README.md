rdf_virtuoso
============

RDF Indexer for Virtuoso OpenSource
